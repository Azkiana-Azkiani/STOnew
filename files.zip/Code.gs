// ================================================================
//  Code.gs — Google Apps Script
//  Device Check · Cinambo
//
//  Setup:
//  1. Buka https://script.google.com → New project
//  2. Paste kode ini
//  3. Isi SPREADSHEET_ID dan FOLDER_ID di bawah
//  4. Deploy → New deployment → Web App
//     • Execute as: Me
//     • Who has access: Anyone
//  5. Copy Web App URL → tempel ke index.html (GAS_URL)
// ================================================================

const SPREADSHEET_ID = 'GANTI_DENGAN_ID_SPREADSHEET_ANDA';
const FOLDER_ID      = 'GANTI_DENGAN_ID_FOLDER_DRIVE_ANDA';

// ── Nama sheet ──────────────────────────────────────────────
const SHEET_NAME = 'Device Check';

// ── Kolom header ────────────────────────────────────────────
const HEADERS = [
  'No', 'Timestamp', 'Lokasi', 'Jenis Perangkat',
  'Barcode', 'Device ID', 'Kondisi',
  'Latitude', 'Longitude',
  'Link Foto', 'Link Video'
];

// ================================================================
//  doPost — menerima kiriman data dari web
// ================================================================
function doPost(e) {
  try {
    const raw  = e.postData.contents;
    const data = JSON.parse(raw);

    // Buka atau buat sheet
    const ss    = SpreadsheetApp.openById(SPREADSHEET_ID);
    let sheet   = ss.getSheetByName(SHEET_NAME);
    if (!sheet) sheet = ss.insertSheet(SHEET_NAME);

    // Buat header jika belum ada
    if (sheet.getLastRow() === 0) {
      sheet.appendRow(HEADERS);
      formatHeader(sheet);
    }

    const folder = DriveApp.getFolderById(FOLDER_ID);
    const ts     = Utilities.formatDate(
      new Date(), 'Asia/Jakarta', 'yyyyMMdd_HHmmss'
    );
    const safe = (data.barcode || data.deviceId || 'noname')
                   .replace(/[^a-zA-Z0-9\-_]/g, '_')
                   .substring(0, 40);

    // ── Upload Foto ──────────────────────────────────────────
    let photoLink = '';
    if (data.photo) {
      const b64   = data.photo.replace(/^data:image\/[^;]+;base64,/, '');
      const bytes = Utilities.base64Decode(b64);
      const blob  = Utilities.newBlob(bytes, 'image/jpeg', `foto_${safe}_${ts}.jpg`);
      const file  = folder.createFile(blob);
      file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
      photoLink = file.getUrl();
    }

    // ── Upload Video ─────────────────────────────────────────
    let videoLink = '';
    if (data.video) {
      const b64     = data.video.replace(/^data:[^;]+;base64,/, '');
      const bytes   = Utilities.base64Decode(b64);
      const mime    = data.videoType || 'video/mp4';
      const ext     = (mime.split('/')[1] || 'mp4').split(';')[0];
      const name    = data.videoName || `video_${safe}_${ts}.${ext}`;
      const blob    = Utilities.newBlob(bytes, mime, name);
      const file    = folder.createFile(blob);
      file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
      videoLink = file.getUrl();
    }

    // ── Tulis ke Spreadsheet ─────────────────────────────────
    const seqNum = sheet.getLastRow(); // header = 1, baris data mulai dari 1

    sheet.appendRow([
      seqNum,                                    // No
      new Date(data.timestamp),                  // Timestamp
      data.lokasi   || '',                       // Lokasi
      data.jenis    || '',                       // Jenis Perangkat
      data.barcode  || '',                       // Barcode
      data.deviceId || '',                       // Device ID
      data.kondisi  || '',                       // Kondisi
      data.latitude  !== null ? data.latitude  : '', // Latitude
      data.longitude !== null ? data.longitude : '', // Longitude
      photoLink,                                 // Link Foto
      videoLink,                                 // Link Video
    ]);

    // Warna kondisi
    const lastRow = sheet.getLastRow();
    colorKondisi(sheet, lastRow, data.kondisi);

    // Buat link clickable
    if (photoLink) {
      const photoCell = sheet.getRange(lastRow, HEADERS.indexOf('Link Foto') + 1);
      photoCell.setFormula(`=HYPERLINK("${photoLink}","📸 Lihat Foto")`);
    }
    if (videoLink) {
      const videoCell = sheet.getRange(lastRow, HEADERS.indexOf('Link Video') + 1);
      videoCell.setFormula(`=HYPERLINK("${videoLink}","🎬 Lihat Video")`);
    }

    return ok({ success: true, photoLink, videoLink, row: lastRow });

  } catch (err) {
    Logger.log('ERROR: ' + err.toString() + '\n' + err.stack);
    return ok({ success: false, error: err.toString() });
  }
}

// ================================================================
//  doGet — health check (opsional)
// ================================================================
function doGet() {
  return ContentService
    .createTextOutput('✅ Device Check API aktif')
    .setMimeType(ContentService.MimeType.TEXT);
}

// ================================================================
//  HELPERS
// ================================================================
function ok(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function formatHeader(sheet) {
  const range = sheet.getRange(1, 1, 1, HEADERS.length);
  range.setBackground('#1a56ff');
  range.setFontColor('#ffffff');
  range.setFontWeight('bold');
  range.setFontSize(11);
  sheet.setFrozenRows(1);
  sheet.setColumnWidth(1, 40);   // No
  sheet.setColumnWidth(2, 160);  // Timestamp
  sheet.setColumnWidth(3, 120);  // Lokasi
  sheet.setColumnWidth(4, 130);  // Jenis
  sheet.setColumnWidth(5, 150);  // Barcode
  sheet.setColumnWidth(6, 130);  // Device ID
  sheet.setColumnWidth(7, 80);   // Kondisi
  sheet.setColumnWidth(8, 100);  // Latitude
  sheet.setColumnWidth(9, 100);  // Longitude
  sheet.setColumnWidth(10, 130); // Link Foto
  sheet.setColumnWidth(11, 130); // Link Video
}

function colorKondisi(sheet, row, kondisi) {
  const col = HEADERS.indexOf('Kondisi') + 1;
  const cell = sheet.getRange(row, col);
  if (kondisi === 'Bagus') {
    cell.setBackground('#e6f8ec').setFontColor('#00b341').setFontWeight('bold');
  } else if (kondisi === 'Rusak') {
    cell.setBackground('#ffe8eb').setFontColor('#e8001d').setFontWeight('bold');
  }
}
