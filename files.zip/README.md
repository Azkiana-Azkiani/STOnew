# 📱 Device Check · Cinambo

Web app pengecekan perangkat yang menyimpan data ke **Google Sheets** dan foto/video ke **Google Drive**.

---

## ✨ Fitur

| # | Fitur | Keterangan |
|---|-------|------------|
| 1 | Pilihan Lokasi | Cinambo RDC / Cinambo DC |
| 2 | Dropdown Perangkat | Laptop, PDA, Printer, Scanner, Handphone |
| 3 | Barcode Scanner | Kamera belakang + input manual |
| 4 | Device ID | Input teks |
| 5 | Kondisi | Bagus / Rusak (dengan kode warna) |
| 6 | Foto + Watermark | Kamera belakang · auto-watermark timestamp & GPS |
| 7 | Video | Pilih dari galeri (maks 50 MB) |
| 8 | Kirim | Upload foto & video ke Drive · tulis ke Sheets |

---

## 🚀 Setup (±15 menit)

### Langkah 1 — Buat Google Drive Folder

1. Buka [drive.google.com](https://drive.google.com)
2. Buat folder baru, misal: **Device Check Cinambo**
3. Buka folder tersebut
4. Salin **Folder ID** dari URL:  
   `https://drive.google.com/drive/folders/`**`INI_FOLDER_ID_ANDA`**

---

### Langkah 2 — Buat Google Sheets

1. Buka [sheets.new](https://sheets.new) untuk membuat spreadsheet baru
2. Beri nama: **Device Check Cinambo**
3. Salin **Spreadsheet ID** dari URL:  
   `https://docs.google.com/spreadsheets/d/`**`INI_SPREADSHEET_ID`**`/edit`

---

### Langkah 3 — Deploy Google Apps Script

1. Buka [script.google.com](https://script.google.com) → **New Project**
2. Hapus kode default, paste seluruh isi file `Code.gs`
3. Edit dua baris di bagian atas:
   ```javascript
   const SPREADSHEET_ID = 'ISI_ID_SPREADSHEET_ANDA';
   const FOLDER_ID      = 'ISI_ID_FOLDER_DRIVE_ANDA';
   ```
4. Klik **Deploy** → **New deployment**
5. Pilih type: **Web app**
6. Konfigurasi:
   - **Execute as**: Me *(akun Google Anda)*
   - **Who has access**: Anyone
7. Klik **Deploy** → izinkan permission yang diminta
8. **Salin Web App URL** (bentuknya: `https://script.google.com/macros/s/...`)

---

### Langkah 4 — Update index.html

Buka `index.html`, cari baris:

```javascript
const GAS_URL = 'PASTE_YOUR_GAS_WEB_APP_URL_HERE';
```

Ganti dengan URL dari Langkah 3:

```javascript
const GAS_URL = 'https://script.google.com/macros/s/AKfy.../exec';
```

---

### Langkah 5 — Deploy ke GitHub Pages

1. Buat repository baru di GitHub (bisa privat atau publik)
2. Upload file `index.html` ke repository
3. Pergi ke **Settings → Pages**
4. Source: **Deploy from a branch**
5. Branch: **main** · Folder: **/ (root)**
6. Klik **Save**
7. Tunggu ±1 menit, lalu akses di:
   ```
   https://[username].github.io/[nama-repository]/
   ```

---

## 📋 Contoh Output di Google Sheets

| No | Timestamp | Lokasi | Jenis | Barcode | Device ID | Kondisi | Lat | Lng | Link Foto | Link Video |
|----|-----------|--------|-------|---------|-----------|---------|-----|-----|-----------|------------|
| 1 | 2025-01-15 09:30:00 | Cinambo RDC | Laptop | ABC123 | LP-001 | ✅ Bagus | -6.9175 | 107.619 | 📸 Lihat | 🎬 Lihat |
| 2 | 2025-01-15 10:15:00 | Cinambo DC | PDA | XYZ789 | PDA-042 | ❌ Rusak | -6.9175 | 107.619 | 📸 Lihat | — |

---

## ⚠️ Catatan Penting

- **Video**: Ukuran maks 50 MB. Lebih besar bisa timeout di GAS.
- **Foto**: Diambil via kamera belakang. Watermark otomatis (waktu + koordinat GPS).
- **Izin browser**: Saat pertama buka, izinkan akses **kamera** dan **lokasi**.
- **CORS**: Sudah ditangani dengan Content-Type `text/plain`.
- **GAS Limit**: Eksekusi maks 6 menit. Video besar mungkin perlu waktu.

---

## 🛠️ Troubleshooting

| Masalah | Solusi |
|---------|--------|
| "Kamera tidak bisa dibuka" | Pastikan HTTPS (GitHub Pages sudah HTTPS) |
| "Lokasi tidak tersedia" | Izinkan akses lokasi di browser |
| "Gagal kirim" | Cek GAS_URL sudah benar & GAS sudah di-deploy |
| Data tidak muncul di Sheets | Cek permission GAS: "Execute as: Me" + "Anyone" |
| Video gagal upload | Kurangi ukuran video, maks 50 MB |

---

## 📁 Struktur File

```
repository/
├── index.html    ← Web app utama (deploy ke GitHub Pages)
└── Code.gs       ← Google Apps Script (deploy ke script.google.com)
```

---

*Dibuat untuk kebutuhan pengecekan perangkat Cinambo RDC & DC*
